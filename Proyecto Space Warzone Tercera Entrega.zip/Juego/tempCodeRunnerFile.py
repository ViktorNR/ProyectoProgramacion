
            estado_bala = "listo"